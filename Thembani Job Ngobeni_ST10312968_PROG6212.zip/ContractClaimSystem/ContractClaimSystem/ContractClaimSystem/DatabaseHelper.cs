﻿using System.Data.SQLite;

namespace ContractClaimSystem
{
    public static class DatabaseHelper
    {
        private const string ConnectionString = "Data Source=claims.db;Version=3;";

        public static void InitializeDatabase()
        {
            using (var connection = new SQLiteConnection(ConnectionString))
            {
                connection.Open();
                string createTableQuery = @"
                    CREATE TABLE IF NOT EXISTS Claims (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        ContractId TEXT NOT NULL,
                        ClaimDescription TEXT NOT NULL,
                        Status TEXT DEFAULT 'Pending'
                    )";
                using (var command = new SQLiteCommand(createTableQuery, connection))
                {
                    command.ExecuteNonQuery();
                }
            }
        }

        public static void AddClaim(string contractId, string claimDescription)
        {
            using (var connection = new SQLiteConnection(ConnectionString))
            {
                connection.Open();
                string insertQuery = "INSERT INTO Claims (ContractId, ClaimDescription) VALUES (@ContractId, @ClaimDescription)";
                using (var command = new SQLiteCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@ContractId", contractId);
                    command.Parameters.AddWithValue("@ClaimDescription", claimDescription);
                    command.ExecuteNonQuery();
                }
            }
        }

        public static SQLiteDataReader GetClaims()
        {
            var connection = new SQLiteConnection(ConnectionString);
            connection.Open();
            string selectQuery = "SELECT * FROM Claims";
            var command = new SQLiteCommand(selectQuery, connection);
            return command.ExecuteReader();
        }
    }
}
