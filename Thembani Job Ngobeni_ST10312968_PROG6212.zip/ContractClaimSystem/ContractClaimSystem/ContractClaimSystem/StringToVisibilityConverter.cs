﻿using ContractClaimSystem;
using System;
using System.Globalization;
using System.Reflection.Metadata;
using System.Security.Claims;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using static System.Net.Mime.MediaTypeNames;
using System.Windows.Input;
using System.Windows.Media.Media3D;
using System.Xml.Linq;

namespace ContractClaimSystem
{
    public class StringToVisibilityConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return string.IsNullOrWhiteSpace(value as string) ? Visibility.Visible : Visibility.Collapsed;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
