﻿using System.Windows;

namespace ContractClaimSystem
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            InitializeDataGrid();
        }

        private void InitializeDataGrid()
        {
            // Example data for the DataGrid
            var data = new[]
            {
                new { Sessions = "Session 1", Programme = "Program A", ModuleCode = "M101", Groups = "Group 1", Rate = 100, Total = 500 },
                new { Sessions = "Session 2", Programme = "Program B", ModuleCode = "M102", Groups = "Group 2", Rate = 150, Total = 750 }
            };

            // Bind data to the DataGrid
            SessionsDataGrid.ItemsSource = data;
        }

        private void SubmitClaim_Click(object sender, RoutedEventArgs e)
        {
            // Handle claim submission logic here
            MessageBox.Show("Claim submitted successfully!");
        }

        private void SessionsDataGrid_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {

        }
    }
}